from ctypes import *
s = cdll.LoadLibrary('files/install.dylib')
s.Validate()

